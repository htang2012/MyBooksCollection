#include "worker2.h"
#include <QImage>
#include <QDebug>
extern QImage *globalImage;
Worker2::Worker2(QObject *parent) : QObject(parent),m_currentcol(0)
{
    worker2_timer = new QTimer;
    connect(worker2_timer, SIGNAL(timeout()),
            this, SLOT(doWork()));
    m_currentcol = globalImage->width()/2;
    worker2_timer->start(100);

}

void Worker2::doWork()
{
  if( m_currentcol >= globalImage->width() /2  )
  {

   for(int row = 0; row < globalImage->height(); ++row)
   {
       qDebug() << row << "," << m_currentcol;
       QRgb value = globalImage->pixel(m_currentcol, row);
       QRgb threshold = qRgb(255,255,255);
       globalImage->setPixel(m_currentcol, row, threshold - value);
       emit update();
   }
   ++m_currentcol;
   if(m_currentcol == globalImage->width())
   {
       worker2_timer->stop();
   }
  }
}
