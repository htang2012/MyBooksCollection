#include "worker2.h"
#include <QFile>
#include <QThread>
#include <QVector>
#include <QDebug>
extern QVector<int> buffer;
Worker2::Worker2(QObject *parent) : QObject(parent), m_count(0)
{

    worker2_timer = new QTimer;
    connect(worker2_timer, SIGNAL(timeout()),
            this, SLOT(doWork()));
   // worker2_timer->start(1000);

}

void Worker2::doWork()
{


}
