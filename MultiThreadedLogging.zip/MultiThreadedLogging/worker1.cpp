#include "worker1.h"
#include <QImage>
#include <QDebug>
extern QImage *globalImage;
Worker1::Worker1(QObject *parent) : QObject(parent),m_currentcol(0)
{
    worker1_timer = new QTimer;
    connect(worker1_timer, SIGNAL(timeout()),
            this, SLOT(doWork()));
    m_halfwidth = globalImage->width();
    m_fullheight = globalImage->height();
    worker1_timer->start(100);

}

void Worker1::doWork()
{
  if( m_currentcol < globalImage->height() )
  {

   for(int row = 0; row < globalImage->height(); ++row)
   {
       qDebug() << row << "," << m_currentcol;
       QRgb value = globalImage->pixel(m_currentcol, row);
       QRgb threshold = qRgb(255,255,255);
       globalImage->setPixel(m_currentcol, row, threshold - value);
       emit update();
   }
   ++m_currentcol;
   if(m_currentcol == globalImage->width() / 2)
   {
       worker1_timer->stop();
   }
  }
}
