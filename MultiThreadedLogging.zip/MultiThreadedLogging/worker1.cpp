#include "worker1.h"
#include <QFile>
#include <QThread>
#include <QVector>
#include <QDebug>
extern QVector<int> buffer;
Worker1::Worker1(QObject *parent) : QObject(parent), m_count(0)
{
    worker1_timer = new QTimer;
    connect(worker1_timer, SIGNAL(timeout()),
            this, SLOT(doWork()));
    index = 0;
    worker1_timer->start(1000);

}

void Worker1::doWork()
{
    qDebug() << buffer.size();
    if(buffer.size() < 10)
    {
      ++m_count;
      buffer.push_back(m_count);
      if(buffer.size() == 10)
      {
          emit bufferFull();
      }
    }


}
