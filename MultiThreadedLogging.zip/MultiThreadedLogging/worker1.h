#ifndef WORKER1_H
#define WORKER1_H

#include <QObject>
#include <QTimer>

class Worker1 : public QObject
{
    Q_OBJECT
public:
    explicit Worker1(QObject *parent = nullptr);

signals:
    void update();
    void finished();
    void bufferFull();

public slots:
    void doWork();
private:
    QTimer *worker1_timer;
    int m_count;
    int index;

};

#endif // WORKER1_H
