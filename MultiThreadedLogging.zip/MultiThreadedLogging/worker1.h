#ifndef WORKER1_H
#define WORKER1_H

#include <QObject>
#include <QTimer>

class Worker1 : public QObject
{
    Q_OBJECT
public:
    explicit Worker1(QObject *parent = nullptr);

signals:
    void update();
    void finished();

public slots:
    void doWork();
private:
    QTimer *worker1_timer;
    int m_currentcol;
    int m_halfwidth;
    int m_fullheight;
};

#endif // WORKER1_H
