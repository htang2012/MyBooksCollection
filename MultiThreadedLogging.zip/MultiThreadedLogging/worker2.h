#ifndef WORKER2_H
#define WORKER2_H

#include <QObject>
#include <QTimer>

class Worker2 : public QObject
{
    Q_OBJECT
public:
    explicit Worker2(QObject *parent = nullptr);

signals:
    void update();
    void finished();

public slots:
    void doWork();
private:
    QTimer *worker2_timer;
    int m_currentcol;
    int m_halfwidth;
    int m_fullheight;
};

#endif // WORKER2_H
