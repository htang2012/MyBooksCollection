#include "mainwidget.h"
#include "worker1.h"
#include "worker2.h"
#include <QApplication>
#include <QThread>
#include <QVector>
#include <QDebug>

QVector<int> buffer;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWidget w;
    w.show();

        QThread *thread1 = new QThread;
        QThread *thread2 = new QThread;
        Worker1 *worker1 = new Worker1;
        Worker2 *worker2 = new Worker2;
        worker1->moveToThread(thread1);
        worker2->moveToThread(thread2);
        thread1->setStackSize(100);
        thread1->start(QThread::LowPriority);
        thread2->start(QThread::HighestPriority);
        qDebug() << thread1->stackSize();
        QObject::connect(thread1, SIGNAL(started()),
                          worker1, SLOT(doWork()));
        QObject::connect(thread2, SIGNAL(started()),
                          worker2, SLOT(doWork()));

        QObject::connect(worker1,SIGNAL(bufferFull()),
                         &w,SLOT(handleBufferFull()));
        QObject::connect(worker2,SIGNAL(finished()),
                         &w,SLOT(closeFile()));

    return a.exec();

}
