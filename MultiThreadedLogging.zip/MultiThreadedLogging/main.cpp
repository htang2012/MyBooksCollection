#include "mainwidget.h"
#include "worker1.h"
#inlcude "worker2.h"
#include <QApplication>
#include <QThread>
#include <QLabel>

QImage *globalImage;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWidget w;
   w.show();
    globalImage = new QImage("D:\\ra1\\My_Data_PSN\\My_Stuff\\test.png");
    QThread *thread1 = new QThread;
    QThread *thread2 = new QThread;
    Worker1 *worker1 = new Worker1;
    Worker2 *worker2 = new Worker2;
    worker1->moveToThread(thread1);
    worker2->moveToThread(thread2);
    thread1->start();
    thread2->start();
    QObject::connect(thread1, SIGNAL(started()),
                      worker, SLOT(doWork()));
    QObject::connect(thread2, SIGNAL(started()),
                      worker, SLOT(doWork()));

    QObject::connect(worker1,SIGNAL(update()),
                     &w,SLOT(displayImage()));
    QObject::connect(worker2,SIGNAL(update()),
                     &w,SLOT(displayImage()));







    return a.exec();
}
