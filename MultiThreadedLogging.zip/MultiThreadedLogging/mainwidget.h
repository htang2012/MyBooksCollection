#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QMouseEvent>
#include <QPainter>
#include <QTimer>


namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent* event);

private slots:
    void mirrorImage();
    void displayImage();
private:
    Ui::MainWidget *ui;

    int m_init_x;
    int m_init_y;
    int m_end_x;
    int m_end_y;
    bool m_mousereleased;



    QTimer *timer;
    int m_activerow;

    void drawLine(int m_init_x, int m_init_y, int m_end_x, int m_end_y);
};

#endif // MAINWIDGET_H
