#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QMessageBox>
#include <QPainter>
#include <QFile>
#include <QVector>
#include <QObject>
extern QVector<int> buffer;

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget),m_init_x(0), m_init_y(0), m_end_x(0), m_end_y(0)
{
    ui->setupUi(this);
    timer = new QTimer;
    m_mousereleased = false;
    m_activerow = 0;
    model = new QStandardItemModel(this);
    model->setRowCount(1);
    model->setColumnCount(10);
    ui->tableView->setModel(model);
    ui->tableView->horizontalHeader()->setVisible(false);
    ui->tableView->verticalHeader()->setVisible(false);

    QObject::connect(timer, SIGNAL(timeout()),
                     this, SLOT(mirrorImage()));
    timer->start(0.25);


   // img.invertPixels();

    /*
   int  value = qRgb(255, 0, 0);
    for(int row = 0; row < img.height();++row)
    {
        for(int col = 0; col < img.width(); ++col)
        {
            QRgb value = img.pixel(col, row);
            QRgb threshold = qRgb(255,255,255);
            img.setPixel(col, row, threshold - value);
        }
    }
    */
    QPixmap p("D:\\ra1\\My_Data_PSN\\My_Stuff\\test.png");
    QImage img = p.toImage().mirrored(true, false);

    ui->imageLabel->setPixmap(QPixmap::fromImage(img));
    ui->imageLabel->setScaledContents(true);
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::mousePressEvent(QMouseEvent *event)
{
    m_init_x = event->x();
    m_init_y = event->y();


}

void MainWidget::mouseReleaseEvent(QMouseEvent *event)
{
    m_end_x = event->x();
    m_end_y = event->y();
    m_mousereleased = true;
    repaint();
}

void MainWidget::paintEvent(QPaintEvent *event)
{
    if(m_mousereleased)
    {
        QPainter painter(this);

        painter.save();
        painter.setRenderHint(QPainter::Antialiasing);
        painter.setRenderHint(QPainter::HighQualityAntialiasing);
        painter.setPen(QPen(Qt::red));
        painter.drawLine(m_init_x, m_init_y, m_end_x, m_end_y);
        painter.restore();

    }
}

void MainWidget::mirrorImage()
{
    int count = buffer.size();
    for(int i = 0; i < count ; ++i)
    {
        QStandardItem *item =  new QStandardItem(QString::number(buffer[i]));
        model->setItem(0,i,item);
    }

    /*QPixmap p = *(ui->imageLabel->pixmap());
    QImage img = p.toImage();
    if ( m_activerow < img.height())
    {
    for(int col = 0; col < img.width(); ++col)
    {
        QRgb value = img.pixel(col, m_activerow);
        QRgb threshold = qRgb(255,255,255);
        img.setPixel(col, m_activerow, threshold - value);
    }

   // QImage img = p.toImage().mirrored(true, false);
    ui->imageLabel->setPixmap(QPixmap::fromImage(img));
    ui->imageLabel->setScaledContents(true);
    m_activerow++;
    }buffer
    */
}

void MainWidget::drawLine(int m_init_x, int m_init_y, int m_end_x, int m_end_y)
{


}
void MainWidget::displayImage()
{
    //ui->imageLabel->setPixmap(QPixmap::fromImage(*globalImage));
    //ui->imageLabel->setScaledContents(true);

}

void MainWidget::closeFile()
{

}

void MainWidget::handleBufferFull()
{
    QMessageBox box;
    box.setText("Buffer is Full");
box.exec();
}



void MainWidget::on_removeButton_clicked()
{
    buffer.pop_front();
}
