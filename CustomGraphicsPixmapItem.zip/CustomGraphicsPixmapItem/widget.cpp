#include "widget.h"
#include "ui_widget.h"
#include <QMenu>
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    scene = new CustomGraphicsScene;
    graphicsview = new CustomGraphicsView;
    scene->setSceneRect(0,0,graphicsview->width(),graphicsview->height());
    graphicsview->setContextMenuPolicy(Qt::CustomContextMenu);
    mainlayout = new QGridLayout;

    asmlThread = new QThread;
    cymerThread = new QThread;
    asmlimagegenerator = new ASMLImageGenerator;
    cymerimagegenerator = new CYMERImageGenerator;
    asmlimagegenerator->moveToThread(asmlThread);
    cymerimagegenerator->moveToThread(cymerThread);


    graphicsview->setScene(scene);
    pixmapItem = new CustomGraphicsPixmapItem;
    pixmapItem->addPixmap(QPixmap("d:\\asml.png"));
    pixmapItem->setPos(QPoint());
    pixmapItem->setFlags(QGraphicsItem::ItemIsMovable);
    scene->addItem(pixmapItem);

    connect(graphicsview, SIGNAL(customContextMenuRequested(const QPoint&)),
            this, SLOT(customContextMenu(const QPoint&)));

    connect(asmlThread, SIGNAL(started()),
            asmlimagegenerator, SLOT(generateImage()));
    connect(asmlimagegenerator, SIGNAL(imageready(CustomGraphicsPixmapItem*)),
            this, SLOT(drawImage(CustomGraphicsPixmapItem*)));

    connect(cymerThread, SIGNAL(started()),
            cymerimagegenerator, SLOT(generateImage()));
    connect(cymerimagegenerator, SIGNAL(imageready(CustomGraphicsPixmapItem*)),
            this, SLOT(drawImage(CustomGraphicsPixmapItem*)));

    mainlayout->addWidget(graphicsview,0,0);
    asmlThread->start();
    //cymerThread->start();
    setLayout(mainlayout);
}
void Widget::myDrawtext(const QPoint &pos)
{
    QGraphicsTextItem *textItem = scene->addText("Raja");
    textItem->setPos(pos);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::customContextMenu(const QPoint& pos)
{
    QPoint globalPos = this->mapToGlobal(pos);


       QMenu myMenu;
       myMenu.addAction("Draw Text");
       myMenu.addAction("Draw Rectangle");
       // ...

       QAction* selectedItem = myMenu.exec(globalPos);
       if (selectedItem->text() == "Draw Text")
       {
           myDrawtext(globalPos);
       }
       else if(selectedItem->text() == "Draw Rectangle")
       {
           // nothing was chosen
       }
}

void Widget::generatePixmaps()
{
    int width = 200;
    int height = 400;
    int random_x = qrand()% width;
    int random_y = qrand() % height;
    qDebug() << "(" <<random_x << "," << random_y << ")";
    CustomGraphicsPixmapItem *item = new CustomGraphicsPixmapItem;
    item->addPixmap(QPixmap(":/images/asml.png"));
    scene->addItem(item);
    item->setPos(QPoint(random_x, random_y));


}

void Widget::drawImage(CustomGraphicsPixmapItem* item)
{
    scene->addItem(item);
    item->setPos(item->position());

}
