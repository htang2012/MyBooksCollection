#ifndef CYMERIMAGEGENERATOR_H
#define CYMERIMAGEGENERATOR_H

#include <QObject>
#include <QTimer>
#include "customgraphicspixmapitem.h"

class CYMERImageGenerator : public QObject
{
    Q_OBJECT
public:
    explicit CYMERImageGenerator(QObject *parent = nullptr);

signals:
    void imageready(CustomGraphicsPixmapItem*);

public slots:
    void generateImage();
private:
    QTimer *timer;
};

#endif // CYMERIMAGEGENERATOR_H
