#include "customgraphicsview.h"

CustomGraphicsView::CustomGraphicsView()
{
 setStyleSheet("background-color:green");
}
