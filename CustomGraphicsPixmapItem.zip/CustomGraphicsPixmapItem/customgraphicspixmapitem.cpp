#include "customgraphicspixmapitem.h"

CustomGraphicsPixmapItem::CustomGraphicsPixmapItem()
{

}

void CustomGraphicsPixmapItem::addPixmap(const QPixmap &pixmap)
{
    setPixmap(pixmap);
}

QPixmap CustomGraphicsPixmapItem::getPixmap() const
{
    this->pixmap();
}


void CustomGraphicsPixmapItem::setPosition(int x, int y)
{
    m_x = x;
    m_y = y;
}

QPoint CustomGraphicsPixmapItem::position()
{
    return QPoint(m_x, m_y);
}
