#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QGridLayout>
#include <QTimer>
#include <QThread>
#include "customgraphicspixmapitem.h"
#include "customgraphicsscene.h"
#include "customgraphicsview.h"
#include "asmlimagegenerator.h"
#include "cymerimagegenerator.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
private slots:
    void customContextMenu(const QPoint &pos);
    void generatePixmaps();
    void drawImage(CustomGraphicsPixmapItem* item);

private:
    void myDrawtext(const QPoint &pos);
    Ui::Widget *ui;
    CustomGraphicsScene *scene;
    CustomGraphicsView *graphicsview;
    CustomGraphicsPixmapItem *pixmapItem;
    QGridLayout *mainlayout;
    QTimer *timer;

    QThread *asmlThread;
    QThread *cymerThread;
    ASMLImageGenerator *asmlimagegenerator;
    CYMERImageGenerator *cymerimagegenerator;

};

#endif // WIDGET_H
