#ifndef CUSTOMGRAPHICSPIXMAPITEM_H
#define CUSTOMGRAPHICSPIXMAPITEM_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

class CustomGraphicsPixmapItem : public QObject, public QGraphicsPixmapItem
{
public:
    CustomGraphicsPixmapItem();
    void addPixmap(const QPixmap& pixmap);
    QPixmap getPixmap() const;
    void setPosition(int x, int y);
    QPoint position();
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event)
    {
        Q_UNUSED(event);
        QPixmap pixmap = this->pixmap();
        QImage image = pixmap.toImage();
        image.invertPixels();;
        addPixmap(QPixmap::fromImage(image));
    }

private:
    int m_x;
    int m_y;
};

#endif // CUSTOMGRAPHICSPIXMAPITEM_H
