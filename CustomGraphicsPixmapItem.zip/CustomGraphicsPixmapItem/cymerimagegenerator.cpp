#include <QCursor>
#include "cymerimagegenerator.h"

CYMERImageGenerator::CYMERImageGenerator(QObject *parent) : QObject(parent)
{
    timer = new QTimer;
    connect(timer, SIGNAL(timeout()),
            this, SLOT(generateImage()));
    timer->start(1000);

}

void CYMERImageGenerator::generateImage()
{
    static int x = 0;
    static int y = 0;
    CustomGraphicsPixmapItem *pixmapItem = new CustomGraphicsPixmapItem;
    pixmapItem->addPixmap(QPixmap(":/images/cymer.jpg"));
    pixmapItem->setPosition(x, y);
    pixmapItem->setCursor(QCursor(Qt::SizeAllCursor));
    x += 100;
    if( 300 == x)
    {
        y += 100;
        x = 0;
    }

    emit imageready(pixmapItem);
}
