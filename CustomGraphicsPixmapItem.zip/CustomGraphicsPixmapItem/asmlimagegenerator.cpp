#include <QCursor>
#include <QWaitCondition>
#include <QMutex>
#include <QThread>
#include "asmlimagegenerator.h"
QWaitCondition  condition;
QMutex mutex;
int count = 0;

ASMLImageGenerator::ASMLImageGenerator(QObject *parent) : QObject(parent)
{
    timer = new QTimer;
    connect(timer, SIGNAL(timeout()),
            this, SLOT(generateImage()));
    timer->start(1000);

}

void ASMLImageGenerator::generateImage()
{
    static int x = 0;
    static int y = 0;
    CustomGraphicsPixmapItem *pixmapItem = new CustomGraphicsPixmapItem;
    pixmapItem->addPixmap(QPixmap(":/images/asml.png"));
    pixmapItem->setPosition(x, y);
    pixmapItem->setCursor(QCursor(Qt::SizeAllCursor));
    x += 100;
    if( 300 == x)
    {
        y += 100;
        x = 0;
    }

    emit imageready(pixmapItem);
    ++count;

    if((count % 3)== 0)
        condition.wakeAll();

}
