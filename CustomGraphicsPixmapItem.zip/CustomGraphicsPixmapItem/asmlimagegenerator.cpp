#include <QCursor>
#include "asmlimagegenerator.h"

ASMLImageGenerator::ASMLImageGenerator(QObject *parent) : QObject(parent)
{
    timer = new QTimer;
    connect(timer, SIGNAL(timeout()),
            this, SLOT(generateImage()));
    timer->start(2000);

}

void ASMLImageGenerator::generateImage()
{
    static int x = 0;
    static int y = 0;
    CustomGraphicsPixmapItem *pixmapItem = new CustomGraphicsPixmapItem;
    pixmapItem->addPixmap(QPixmap(":/images/asml.png"));
    pixmapItem->setPosition(x, y);
    pixmapItem->setCursor(QCursor(Qt::SizeAllCursor));
    x += 100;
    if( 300 == x)
    {
        y += 100;
        x = 0;
    }

    emit imageready(pixmapItem);
}
