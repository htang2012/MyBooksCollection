#ifndef CUSTOMGRAPHICSSCENE_H
#define CUSTOMGRAPHICSSCENE_H

#include <QObject>
#include <QGraphicsScene>

class CustomGraphicsScene : public QGraphicsScene
{
public:
    CustomGraphicsScene();
};

#endif // CUSTOMGRAPHICSSCENE_H
