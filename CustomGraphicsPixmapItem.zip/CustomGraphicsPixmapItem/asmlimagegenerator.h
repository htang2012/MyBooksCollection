#ifndef ASMLIMAGEGENERATOR_H
#define ASMLIMAGEGENERATOR_H

#include <QObject>
#include <QTimer>
#include "customgraphicspixmapitem.h"

class ASMLImageGenerator : public QObject
{
    Q_OBJECT
public:
    explicit ASMLImageGenerator(QObject *parent = nullptr);

signals:
    void imageready(CustomGraphicsPixmapItem*);

public slots:
    void generateImage();
private:
    QTimer *timer;
};

#endif // ASMLIMAGEGENERATOR_H
