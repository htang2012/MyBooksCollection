#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "customgraphicsscene.h"
#include "customgraphicsview.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_actionOpenImage_triggered();

    void on_actionZoom_In_triggered();

    void on_actionZoom_Out_triggered();

private:
    void initialize();
    CustomGraphicsScene *scene;
    CustomGraphicsPixmapItem *m_gpixmapitem;
    CustomGraphicsView *graphicsview;
    qreal scalefactor;
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
