#ifndef CUSTOMGRAPHICSPIXMAPITEM_H
#define CUSTOMGRAPHICSPIXMAPITEM_H

#include <QObject>
#include <QGraphicsPixmapItem>

class CustomGraphicsPixmapItem : public QObject, public QGraphicsPixmapItem
{
public:
    CustomGraphicsPixmapItem();
private:

};

#endif // CUSTOMGRAPHICSPIXMAPITEM_H
