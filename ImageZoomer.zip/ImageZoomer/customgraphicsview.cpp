#include "customgraphicsview.h"
#include  <QDebug>

CustomGraphicsView::CustomGraphicsView(QWidget *)
{
}

void CustomGraphicsView::mousePressEvent(QMouseEvent *event)
{
    QPointF pos = mapToScene(event->x(), event->y());
    qDebug() << pos.x() <<" , " << pos.y();

}


