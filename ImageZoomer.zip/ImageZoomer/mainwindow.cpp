#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initialize();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionOpenImage_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this,"Open Image",tr("D:\\"),tr("Image Files (*.png *.jpg *.bmp)"));
    if(!filename.isEmpty())
    {

        m_gpixmapitem->setPixmap(QPixmap(filename));
        m_gpixmapitem->setPos(-100, -200);
        m_gpixmapitem->setFlags(QGraphicsItem::ItemIsMovable);
       // m_gpixmapitem->setScale(scalefactor);
        scene->addItem(m_gpixmapitem);

    }
}

void MainWindow::initialize()
{
    scalefactor = 1.0;
    m_gpixmapitem = new CustomGraphicsPixmapItem;
    scene = new CustomGraphicsScene;
    graphicsview = new CustomGraphicsView(this);
    setCentralWidget(graphicsview);
    scene->setSceneRect(0,0,400, 400);
    graphicsview->setScene(scene);

}

void MainWindow::on_actionZoom_In_triggered()
{
    scalefactor += 0.2;
    m_gpixmapitem->setScale(scalefactor);
}

void MainWindow::on_actionZoom_Out_triggered()
{
    scalefactor -= 0.2;
    m_gpixmapitem->setScale(scalefactor);
}
