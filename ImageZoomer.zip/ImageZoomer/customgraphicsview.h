#ifndef CUSTOMGRAPHICSVIEW_H
#define CUSTOMGRAPHICSVIEW_H

#include <QObject>
#include <QGraphicsView>
#include <QMouseEvent>
#include "customgraphicspixmapitem.h"

class CustomGraphicsView : public QGraphicsView
{
public:
    CustomGraphicsView(QWidget*);
    void mousePressEvent(QMouseEvent *event);
private:


};

#endif // CUSTOMGRAPHICSVIEW_H
