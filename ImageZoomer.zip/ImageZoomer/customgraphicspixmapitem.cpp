#include "customgraphicspixmapitem.h"

CustomGraphicsPixmapItem::CustomGraphicsPixmapItem()
{

}
